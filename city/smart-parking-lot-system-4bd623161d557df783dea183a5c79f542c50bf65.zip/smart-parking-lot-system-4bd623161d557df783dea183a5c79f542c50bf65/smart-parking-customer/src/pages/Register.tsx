import { useState } from "react"
import { useNavigate } from "react-router-dom"
import { useForm } from "react-hook-form"
import { zodResolver } from "@hookform/resolvers/zod"
import { z } from "zod"
import { Lock, Mail, User, Eye, EyeOff, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { AuthLayout } from "@/components/layout/AuthLayout"
import { authApi } from "@/api/auth"
import { useAuthStore } from "@/store/authStore"
import { useLanguage } from "@/lib/i18n"
import { toast } from "@/components/ui/toaster"
import { strongPassword } from "@/lib/passwordSchema"

const registerSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  email: z.string().email("Invalid email address"),
  phone: z.string().trim().min(8, "Phone number is required for wallet payments").max(20, "Phone number is too long"),
  password: strongPassword,
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
})

type RegisterForm = z.infer<typeof registerSchema>

export default function Register() {
  const navigate = useNavigate()
  const { t } = useLanguage()
  const { setTokens, setUser, setVerifying } = useAuthStore()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [showConfirmPassword, setShowConfirmPassword] = useState(false)

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm<RegisterForm>({
    resolver: zodResolver(registerSchema),
  })

  const onSubmit = async (data: RegisterForm) => {
    setIsLoading(true)
    try {
      const { confirmPassword, ...registerData } = data
      await authApi.register(registerData)

      // Auto login to start verification flow
      const tokens = await authApi.login({ email: data.email, password: data.password })
      setTokens(tokens.access_token, tokens.refresh_token)

      const user = await authApi.getMe()

      // Guard: ensure the registered account has the customer role
      if (!user.role || user.role.name.toLowerCase() !== "customer") {
        toast.error("Access denied. This is a customer-only portal.")
        const { logout } = useAuthStore.getState()
        logout()
        return
      }

      setUser(user)

      try {
        await authApi.sendOTP({ email: user.email })
        setVerifying(true)
        toast.success("Account created! Verification OTP sent to your email.")
        navigate("/verify-email")
      } catch {
        toast.success("Account created! Please sign in to verify your email.")
        navigate("/login")
      }
    } catch (error: any) {
      toast.error(error.response?.data?.message || "Registration failed")
    } finally {
      setIsLoading(false)
    }
  }

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSubmit(onSubmit)(e)
  }

  return (
    <AuthLayout>
      <h1 className="text-xl font-bold text-foreground mb-2">{t("nav.register", "Register")}</h1>
      <p className="text-sm text-muted-foreground mb-8">
        {t("home.cta_subtitle", "Sign up to start using Smart Parking.")}
      </p>

      <form onSubmit={handleFormSubmit} className="flex flex-col gap-5">
        <div className="flex flex-col gap-1.5">
          <Label htmlFor="name" className="text-sm text-foreground font-bold">{t("profile.name", "Full Name")}</Label>
          <div className="relative">
            <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="name"
              placeholder="John Doe"
              className="pl-10"
              {...register("name")}
            />
          </div>
          {errors.name && (
            <p className="text-xs text-destructive mt-1">{errors.name.message}</p>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="email" className="text-sm text-foreground font-bold">{t("profile.email", "Email Address")}</Label>
          <div className="relative">
            <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              className="pl-10"
              {...register("email")}
            />
          </div>
          {errors.email && (
            <p className="text-xs text-destructive mt-1">{errors.email.message}</p>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="phone" className="text-sm text-foreground font-bold">{t("profile.phone", "Phone Number")}</Label>
          <div className="flex">
            <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-input bg-muted text-sm font-medium text-muted-foreground select-none">
              +959
            </span>
            <Input
              id="phone"
              type="tel"
              inputMode="numeric"
              placeholder="XXXXXXXXX"
              className="rounded-l-none pl-3"
              {...register("phone", {
                setValueAs: (v: string) => {
                  const digits = v.replace(/^\+?959/, "").replace(/\D/g, "")
                  return digits ? `+959${digits}` : ""
                },
              })}
              onChange={(e) => {
                const raw = e.target.value.replace(/^\+?959/, "").replace(/\D/g, "")
                e.target.value = raw
                setValue("phone", raw ? `+959${raw}` : "", { shouldValidate: true })
              }}
            />
          </div>
          <p className="text-xs text-muted-foreground">Used for digital wallet payments. You can change this later in your profile.</p>
          {errors.phone && (
            <p className="text-xs text-destructive mt-1">{errors.phone.message}</p>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="password" className="text-sm text-foreground font-bold">{t("profile.change_password", "Password")}</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="password"
              type={showPassword ? "text" : "password"}
              placeholder="••••••••"
              className="pl-10 pr-10"
              {...register("password")}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.password && (
            <p className="text-xs text-destructive mt-1">{errors.password.message}</p>
          )}
        </div>

        <div className="flex flex-col gap-1.5">
          <Label htmlFor="confirmPassword" className="text-sm text-foreground font-bold">{t("profile.change_password", "Confirm Password")}</Label>
          <div className="relative">
            <Lock className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
            <Input
              id="confirmPassword"
              type={showConfirmPassword ? "text" : "password"}
              placeholder="••••••••"
              className="pl-10 pr-10"
              {...register("confirmPassword")}
            />
            <button
              type="button"
              onClick={() => setShowConfirmPassword(!showConfirmPassword)}
              className="absolute right-3 top-3 text-muted-foreground hover:text-foreground transition-colors"
            >
              {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
          {errors.confirmPassword && (
            <p className="text-xs text-destructive mt-1">{errors.confirmPassword.message}</p>
          )}
        </div>

        <Button type="submit" className="w-full h-11" disabled={isLoading}>
          {isLoading ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
          {isLoading ? "Creating Account..." : t("nav.register", "Register")}
        </Button>

        <div className="text-center text-sm">
          <span className="text-muted-foreground">Already have an account? </span>
          <button
            type="button"
            onClick={() => navigate("/login")}
            className="text-primary hover:underline font-medium"
          >
            {t("nav.login", "Log in")}
          </button>
        </div>
      </form>
    </AuthLayout>
  )
}


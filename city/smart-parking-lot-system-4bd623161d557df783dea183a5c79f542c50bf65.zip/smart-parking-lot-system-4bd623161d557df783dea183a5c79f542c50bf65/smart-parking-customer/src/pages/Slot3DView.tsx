import { useState, useEffect, useRef, Suspense } from "react"
import { useParams, useNavigate, useSearchParams } from "react-router-dom"
import { Canvas, useThree, useFrame } from "@react-three/fiber"
import { OrbitControls, Text, Box } from "@react-three/drei"
import * as THREE from "three"
import Navbar from "@/components/layout/Navbar"
import Footer from "@/components/layout/Footer"
import { LocationTrackBar } from "@/components/parking/LocationTrackBar"
import { ParkingTrackModal } from "@/components/parking/ParkingTrackModal"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import {
  ArrowLeft, AlertCircle, Sun, Moon, Maximize2, Minimize2,
  RotateCw, Layers, Hash, MapPin, ParkingSquare, Car, Navigation2, Clock,
  Briefcase, User, Mail, Phone, Building2,
} from "lucide-react"
import { trackParkingSlot, type ParkingTrackTarget } from "@/lib/parkingTrack"
import { parkingSlotsApi } from "@/api/parkingSlots"
import { parkingFloorsApi } from "@/api/parkingFloors"
import { parkingLotsApi } from "@/api/parkingLots"
import type { ParkingSlotOut } from "@/api/types"
import type { ParkingFloorOut } from "@/api/parkingFloors"
import type { ParkingLotOut } from "@/api/types"

const CAR_PALETTE = [
  "#f43f5e", // Rose Red
  "#3b82f6", // Vibrant Blue
  "#eab308", // Bright Gold
  "#f8fafc", // Pure White
  "#94a3b8", // Silver Chrome
  "#f97316", // Neon Orange
  "#10b981", // Emerald Green
  "#a855f7", // Electric Purple
]

function adjustBrightness(hex: string, amount: number): string {
  const c = hex.replace("#", "")
  const n = parseInt(c, 16)
  const r = Math.min(255, Math.max(0, (n >> 16) + amount))
  const g = Math.min(255, Math.max(0, ((n >> 8) & 0xff) + amount))
  const b = Math.min(255, Math.max(0, (n & 0xff) + amount))
  return `#${((1 << 24) | (r << 16) | (g << 8) | b).toString(16).slice(1)}`
}

function WebGLFallback({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-8 gap-4">
      <div className="size-16 rounded bg-amber-500/10 flex items-center justify-center">
        <AlertCircle className="size-8 text-amber-500" />
      </div>
      <div>
        <h3 className="text-lg font-bold mb-1">3D View Unavailable</h3>
        <p className="text-muted-foreground text-sm">{message}</p>
      </div>
    </div>
  )
}

function CarTopView({ slotId, bw, bl }: { slotId: number; bw: number; bl: number }) {
  const color = CAR_PALETTE[slotId % CAR_PALETTE.length]
  const isWhite = color === "#f8fafc" || color === "#ffffff"
  const isTaxi = (slotId % 5 === 2) || color === "#eab308"
  const darker = adjustBrightness(color, -40)

  const carW = bw * 0.82
  const carL = bl * 0.82

  return (
    <group position={[0, 0, 0]}>
      {/* Soft Ground Shadow */}
      <mesh position={[0, 0.02, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[carW * 1.15, carL * 1.1]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.35} />
      </mesh>

      {/* Main Car Body Chassis */}
      <Box args={[carW, 0.32, carL]} position={[0, 0.22, 0]}>
        <meshStandardMaterial color={color} roughness={0.25} metalness={0.45} />
      </Box>

      {/* Front Hood Curve */}
      <Box args={[carW * 0.94, 0.18, carL * 0.28]} position={[0, 0.28, -carL * 0.34]}>
        <meshStandardMaterial color={color} roughness={0.25} metalness={0.45} />
      </Box>

      {/* Cabin / Roof Structure */}
      <Box args={[carW * 0.78, 0.26, carL * 0.44]} position={[0, 0.44, carL * 0.02]}>
        <meshStandardMaterial color={isWhite ? "#f1f5f9" : darker} roughness={0.3} metalness={0.3} />
      </Box>

      {/* Front Windshield (Angled dark glass) */}
      <Box args={[carW * 0.74, 0.24, 0.08]} position={[0, 0.43, -carL * 0.2]} rotation={[0.4, 0, 0]}>
        <meshStandardMaterial color="#0f172a" roughness={0.1} metalness={0.8} transparent opacity={0.9} />
      </Box>

      {/* Rear Window */}
      <Box args={[carW * 0.72, 0.22, 0.08]} position={[0, 0.43, carL * 0.23]} rotation={[-0.35, 0, 0]}>
        <meshStandardMaterial color="#0f172a" roughness={0.1} metalness={0.8} transparent opacity={0.9} />
      </Box>

      {/* Side Windows */}
      <Box args={[carW * 0.81, 0.2, carL * 0.36]} position={[0, 0.44, carL * 0.02]}>
        <meshStandardMaterial color="#1e293b" roughness={0.1} metalness={0.7} transparent opacity={0.85} />
      </Box>

      {/* Side Mirrors */}
      <Box args={[0.18, 0.12, 0.22]} position={[-carW / 2 - 0.08, 0.34, -carL * 0.15]}>
        <meshStandardMaterial color={color} roughness={0.3} />
      </Box>
      <Box args={[0.18, 0.12, 0.22]} position={[carW / 2 + 0.08, 0.34, -carL * 0.15]}>
        <meshStandardMaterial color={color} roughness={0.3} />
      </Box>

      {/* Front Headlights (Glow Amber/Yellow LED) */}
      <Box args={[carW * 0.24, 0.1, 0.08]} position={[-carW * 0.28, 0.26, -carL / 2 - 0.01]}>
        <meshStandardMaterial color="#fef08a" emissive="#fef08a" emissiveIntensity={0.9} />
      </Box>
      <Box args={[carW * 0.24, 0.1, 0.08]} position={[carW * 0.28, 0.26, -carL / 2 - 0.01]}>
        <meshStandardMaterial color="#fef08a" emissive="#fef08a" emissiveIntensity={0.9} />
      </Box>

      {/* Rear Taillights (Red LED) */}
      <Box args={[carW * 0.26, 0.08, 0.08]} position={[-carW * 0.28, 0.26, carL / 2 + 0.01]}>
        <meshStandardMaterial color="#ef4444" emissive="#dc2626" emissiveIntensity={0.8} />
      </Box>
      <Box args={[carW * 0.26, 0.08, 0.08]} position={[carW * 0.28, 0.26, carL / 2 + 0.01]}>
        <meshStandardMaterial color="#ef4444" emissive="#dc2626" emissiveIntensity={0.8} />
      </Box>

      {/* 4 Wheels */}
      <Box args={[0.14, 0.24, 0.44]} position={[-carW / 2 - 0.02, 0.12, -carL * 0.28]}>
        <meshStandardMaterial color="#18181b" roughness={0.8} />
      </Box>
      <Box args={[0.14, 0.24, 0.44]} position={[carW / 2 + 0.02, 0.12, -carL * 0.28]}>
        <meshStandardMaterial color="#18181b" roughness={0.8} />
      </Box>
      <Box args={[0.14, 0.24, 0.44]} position={[-carW / 2 - 0.02, 0.12, carL * 0.28]}>
        <meshStandardMaterial color="#18181b" roughness={0.8} />
      </Box>
      <Box args={[0.14, 0.24, 0.44]} position={[carW / 2 + 0.02, 0.12, carL * 0.28]}>
        <meshStandardMaterial color="#18181b" roughness={0.8} />
      </Box>

      {/* TAXI Roof Box Sign */}
      {isTaxi && (
        <group position={[0, 0.62, 0]}>
          <Box args={[carW * 0.45, 0.14, 0.22]}>
            <meshStandardMaterial color="#fef08a" emissive="#eab308" emissiveIntensity={0.7} roughness={0.2} />
          </Box>
          <Text position={[0, 0, -0.12]} fontSize={0.1} color="#000000" fontWeight="bold" anchorX="center" anchorY="middle">
            TAXI
          </Text>
        </group>
      )}
    </group>
  )
}

function DashedCenterLine({ totalWidth, z, isNightMode }: { totalWidth: number; z: number; isNightMode: boolean }) {
  const dashLen = 1.5
  const dashGap = 1.0
  const count = Math.floor(totalWidth / (dashLen + dashGap))
  const startX = -(count * (dashLen + dashGap)) / 2 + dashLen / 2

  return (
    <>
      {Array.from({ length: count }).map((_, i) => (
        <Box key={i} args={[dashLen, 0.06, 0.16]} position={[startX + i * (dashLen + dashGap), 0.03, z]}>
          <meshStandardMaterial
            color={isNightMode ? "#38bdf8" : "#ffffff"}
            emissive={isNightMode ? "#0284c7" : "#ffffff"}
            emissiveIntensity={isNightMode ? 0.6 : 0.1}
          />
        </Box>
      ))}
    </>
  )
}

function SelectedSlotAnimation({ sw, sd }: { sw: number; sd: number }) {
  const padMatRef = useRef<THREE.MeshStandardMaterial>(null)
  const ringRef = useRef<THREE.Mesh>(null)
  const ringMatRef = useRef<THREE.MeshStandardMaterial>(null)
  const labelRef = useRef<THREE.Group>(null)
  const timeRef = useRef(0)

  useFrame((_, delta) => {
    timeRef.current += delta
    const t = timeRef.current

    if (padMatRef.current) {
      padMatRef.current.emissiveIntensity = 0.6 + Math.sin(t * 4) * 0.4
      padMatRef.current.opacity = 0.45 + Math.sin(t * 3) * 0.18
    }

    if (ringRef.current && ringMatRef.current) {
      const ringScale = 1 + ((t * 0.8) % 1) * 0.4
      const ringOpacity = Math.max(0, 1 - ((t * 0.8) % 1))
      ringRef.current.scale.set(ringScale, 1, ringScale)
      ringMatRef.current.opacity = ringOpacity * 0.7
    }

    if (labelRef.current) {
      labelRef.current.position.y = 1.8 + Math.sin(t * 3.5) * 0.2
    }
  })

  return (
    <>
      <Box args={[sw - 0.08, 0.05, sd - 0.08]} position={[0, 0.025, 0]}>
        <meshStandardMaterial
          ref={padMatRef}
          color="#3b82f6"
          emissive="#3b82f6"
          emissiveIntensity={0.7}
          transparent
          opacity={0.45}
        />
      </Box>

      <group ref={ringRef} position={[0, 0.05, 0]}>
        <Box args={[sw + 0.2, 0.04, sd + 0.2]}>
          <meshStandardMaterial
            ref={ringMatRef}
            color="#3b82f6"
            emissive="#3b82f6"
            emissiveIntensity={0.9}
            transparent
            opacity={0.7}
          />
        </Box>
      </group>

      <group ref={labelRef} position={[0, 1.8, -sd / 2 - 0.5]}>
        <Text fontSize={0.65} color="#60a5fa" anchorX="center" anchorY="middle" fontWeight="bold">
          Target Slot
        </Text>
      </group>
    </>
  )
}

function ParkingSlot3D({
  slot, position, sw, sd, isNightMode, onClick, isHighlighted, isReserved,
}: {
  slot: ParkingSlotOut
  position: [number, number, number]
  sw: number
  sd: number
  isNightMode: boolean
  onClick: () => void
  isHighlighted: boolean
  isReserved?: boolean
}) {
  const isOccupied = slot.status === "OCCUPIED"
  const isSlotReserved = isReserved || slot.status === "RESERVED"
  const lw = 0.18
  const lh = 0.08

  // Red = Occupied (car present), Amber = Reserved (session active, no car yet), Green = Available
  const padColor = isOccupied
    ? (isNightMode ? "#dc2626" : "#ef4444")
    : isSlotReserved
      ? (isNightMode ? "#d97706" : "#f59e0b")
      : (isNightMode ? "#059669" : "#10b981")

  const padEmissive = isOccupied
    ? (isNightMode ? "#b91c1c" : "#dc2626")
    : isSlotReserved
      ? (isNightMode ? "#f59e0b" : "#d97706")
      : (isNightMode ? "#10b981" : "#10b981")

  const padEmissiveIntensity = isNightMode
    ? (isOccupied ? 0.1 : isSlotReserved ? 0.6 : 0.35)
    : (isOccupied ? 0.1 : isSlotReserved ? 0.4 : 0.1)

  const padOpacity = isNightMode
    ? (isOccupied ? 0.5 : isSlotReserved ? 0.55 : 0.35)
    : (isOccupied ? 0.3 : isSlotReserved ? 0.45 : 0.28)

  const frameEmissive = isHighlighted
    ? "#f59e0b"
    : isSlotReserved
      ? "#fbbf24"
      : isNightMode
        ? "#38bdf8"
        : "#ffffff"

  const frameEmissiveIntensity = isHighlighted ? 0.8 : isSlotReserved ? 0.5 : isNightMode ? 0.5 : 0.08

  return (
    <group
      position={position}
      onClick={(e) => { e.stopPropagation(); onClick() }}
      onPointerOver={(e) => { e.stopPropagation(); document.body.style.cursor = "pointer" }}
      onPointerOut={() => { document.body.style.cursor = "default" }}
    >
      {isHighlighted ? (
        <SelectedSlotAnimation sw={sw} sd={sd} />
      ) : (
        <Box args={[sw - 0.08, 0.04, sd - 0.08]} position={[0, 0.02, 0]}>
          <meshStandardMaterial
            color={padColor}
            emissive={padEmissive}
            emissiveIntensity={padEmissiveIntensity}
            transparent
            opacity={padOpacity}
          />
        </Box>
      )}

      {/* 4-sided full rectangle frame lines */}
      <Box args={[lw, lh, sd]} position={[-sw / 2, lh / 2, 0]}>
        <meshStandardMaterial
          color={isNightMode ? "#e0f2fe" : "#ffffff"}
          emissive={frameEmissive}
          emissiveIntensity={frameEmissiveIntensity}
        />
      </Box>
      <Box args={[lw, lh, sd]} position={[sw / 2, lh / 2, 0]}>
        <meshStandardMaterial
          color={isNightMode ? "#e0f2fe" : "#ffffff"}
          emissive={frameEmissive}
          emissiveIntensity={frameEmissiveIntensity}
        />
      </Box>
      <Box args={[sw, lh, lw]} position={[0, lh / 2, sd / 2]}>
        <meshStandardMaterial
          color={isNightMode ? "#e0f2fe" : "#ffffff"}
          emissive={frameEmissive}
          emissiveIntensity={frameEmissiveIntensity}
        />
      </Box>
      <Box args={[sw, lh, lw]} position={[0, lh / 2, -sd / 2]}>
        <meshStandardMaterial
          color={isNightMode ? "#e0f2fe" : "#ffffff"}
          emissive={frameEmissive}
          emissiveIntensity={frameEmissiveIntensity}
        />
      </Box>

      {isOccupied && (
        <group position={[0, 0, 0]}>
          <CarTopView slotId={slot.id} bw={sw * 0.68} bl={sd * 0.76} />
        </group>
      )}

      {!isOccupied && (
        <Text
          position={[0, 0.35, 0]}
          fontSize={0.6}
          color={isHighlighted ? "#fbbf24" : isSlotReserved ? "#fbbf24" : isNightMode ? "#f8fafc" : "#ffffff"}
          anchorX="center"
          anchorY="middle"
          fontWeight="bold"
        >
          {slot.slot_number}
        </Text>
      )}
    </group>
  )
}

function ParkingFloor3D({
  floor, slots, y, floorIndex, isNightMode, onSlotClick, highlightedSlotId, reservedSlotIds,
}: {
  floor: ParkingFloorOut
  slots: ParkingSlotOut[]
  y: number
  floorIndex: number
  isNightMode: boolean
  onSlotClick: (s: ParkingSlotOut) => void
  highlightedSlotId: number | null
  reservedSlotIds: Set<number>
}) {
  const sw = 3.2
  const sd = 5.2
  const sg = 0.6
  const laneW = 6.0
  const spr = 5
  const floorPad = 2

  const bySection = slots.reduce((acc, slot) => {
    const sec = slot.section || "Main"
    if (!acc[sec]) acc[sec] = []
    acc[sec].push(slot)
    return acc
  }, {} as Record<string, ParkingSlotOut[]>)

  const sections = Object.entries(bySection)
  let zCursor = 0
  const sectionLayouts = sections.map(([name, secSlots]) => {
    const rows = Math.ceil(secSlots.length / spr)
    const layout = { name, secSlots, startZ: zCursor, rows }
    zCursor += rows * (sd + sg) + laneW
    return layout
  })

  const totalDepth = Math.max(zCursor, 10) + floorPad
  const totalWidth = spr * (sw + sg) + 4 + floorPad

  const nightAsphalts = ["#090d16", "#0b0f19", "#0e1322", "#0a0e1c"]
  const dayAsphalts = ["#334155", "#374151", "#475569", "#3b4252"]

  const asphaltColor = isNightMode
    ? nightAsphalts[floorIndex % nightAsphalts.length]
    : dayAsphalts[floorIndex % dayAsphalts.length]

  return (
    <group position={[0, y, 0]}>
      <Box args={[totalWidth, 0.12, totalDepth]} position={[0, 0, (totalDepth - floorPad) / 2]}>
        <meshStandardMaterial
          color={asphaltColor}
          roughness={isNightMode ? 0.9 : 0.8}
          metalness={isNightMode ? 0.15 : 0.05}
        />
      </Box>

      {/* Floor label in neon cyan for night mode */}
      <Text
        position={[-totalWidth / 2 - 0.8, 1.4, (totalDepth - floorPad) / 2]}
        fontSize={1.0}
        color={isNightMode ? "#38bdf8" : "#475569"}
        anchorX="right"
        anchorY="middle"
        fontWeight="bold"
      >
        {floor.floor_name || `F${floorIndex + 1}`}
      </Text>

      {sectionLayouts.map(({ name, secSlots, startZ, rows }) => {
        const slotsPerColumn = rows
        const rowWidth = spr * (sw + sg) - sg
        const sectionMidZ = startZ + (slotsPerColumn * (sd + sg)) / 2 + sd / 2
        const laneZ = startZ + slotsPerColumn * (sd + sg) + laneW / 2

        return (
          <group key={name}>
            <DashedCenterLine totalWidth={rowWidth + 1} z={laneZ} isNightMode={isNightMode} />
            {name !== "Main" && (
              <Text
                position={[-rowWidth / 2 - 0.3, 0.8, sectionMidZ]}
                fontSize={0.5}
                color={isNightMode ? "#94a3b8" : "#94a3b8"}
                anchorX="right"
                anchorY="middle"
                fontWeight="bold"
              >
                {name}
              </Text>
            )}

            {secSlots.map((slot, idx) => {
              const row = Math.floor(idx / spr)
              const col = idx % spr
              const x = (col - (spr - 1) / 2) * (sw + sg)
              const z = startZ + row * (sd + sg) + sd / 2
              return (
                <ParkingSlot3D
                  key={slot.id}
                  slot={slot}
                  position={[x, 0.06, z]}
                  sw={sw}
                  sd={sd}
                  isNightMode={isNightMode}
                  onClick={() => onSlotClick(slot)}
                  isHighlighted={slot.id === highlightedSlotId}
                  isReserved={reservedSlotIds.has(slot.id)}
                />
              )
            })}
          </group>
        )
      })}
    </group>
  )
}

function Slot3DScene({
  floors, slotsByFloor, isNightMode, highlightedSlotId, isAutoRotate, reservedSlotIds,
}: {
  floors: ParkingFloorOut[]
  slotsByFloor: Record<number, ParkingSlotOut[]>
  isNightMode: boolean
  highlightedSlotId: number | null
  isAutoRotate: boolean
  reservedSlotIds: Set<number>
}) {
  const { scene } = useThree()

  useEffect(() => {
    scene.background = new THREE.Color(isNightMode ? "#09090b" : "#f1f5f9")
    scene.fog = new THREE.FogExp2(isNightMode ? "#09090b" : "#f1f5f9", 0.008)
  }, [isNightMode, scene])

  return (
    <>
      <ambientLight intensity={isNightMode ? 0.95 : 1.6} />

      <directionalLight
        position={[0, 60, 20]}
        intensity={isNightMode ? 0.8 : 2.0}
        color={isNightMode ? "#fed7aa" : "#ffffff"}
        castShadow
      />

      {isNightMode && (
        <>
          <pointLight position={[0, 30, 10]} intensity={2.2} color="#FF8F00" distance={60} />
          <pointLight position={[-18, 22, -10]} intensity={1.8} color="#fbbf24" distance={50} />
          <pointLight position={[18, 22, 30]} intensity={1.8} color="#f59e0b" distance={50} />
          <pointLight position={[0, 15, -20]} intensity={1.5} color="#10b981" distance={45} />
        </>
      )}

      {!isNightMode && (
        <directionalLight position={[-20, 40, -20]} intensity={0.8} color="#fef08a" />
      )}

      <OrbitControls
        enableZoom
        enablePan
        enableRotate
        autoRotate={isAutoRotate}
        autoRotateSpeed={2.0}
        maxPolarAngle={Math.PI / 2.05}
        minPolarAngle={0}
      />

      <group>
        {floors.map((floor, index) => (
          <ParkingFloor3D
            key={floor.id}
            floor={floor}
            slots={slotsByFloor[floor.id] || []}
            y={index * 4}
            floorIndex={index}
            isNightMode={isNightMode}
            onSlotClick={() => { }}
            highlightedSlotId={highlightedSlotId}
            reservedSlotIds={reservedSlotIds}
          />
        ))}
      </group>
    </>
  )
}

function checkWebGLSupport(): boolean {
  try {
    const canvas = document.createElement("canvas")
    const gl = (canvas.getContext("webgl") || canvas.getContext("experimental-webgl")) as WebGLRenderingContext | null
    if (!gl) return false
    const loseContext = gl.getExtension("WEBGL_lose_context")
    if (loseContext) loseContext.loseContext()
    return true
  } catch {
    return false
  }
}

import { useTheme } from "next-themes"

export default function Slot3DView() {
  const { id: slotId } = useParams<{ id: string }>()
  const [searchParams] = useSearchParams()
  const routeId = searchParams.get("id")
  const id = Number(routeId || slotId)
  const navigate = useNavigate()

  const { resolvedTheme, setTheme } = useTheme()
  const isNightMode = resolvedTheme === "dark"

  const containerRef = useRef<HTMLDivElement>(null)
  const [slot, setSlot] = useState<ParkingSlotOut | null>(null)
  const [floor, setFloor] = useState<ParkingFloorOut | null>(null)
  const [lot, setLot] = useState<ParkingLotOut | null>(null)
  const [floors, setFloors] = useState<ParkingFloorOut[]>([])
  const [slotsByFloor, setSlotsByFloor] = useState<Record<number, ParkingSlotOut[]>>({})
  const [reservedSlotIds] = useState<Set<number>>(new Set())
  const [isLoading, setIsLoading] = useState(true)
  const [webGLError, setWebGLError] = useState<string | null>(null)
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [isAutoRotate, setIsAutoRotate] = useState(true)
  const [activeNavigation, setActiveNavigation] = useState<ParkingTrackTarget | null>(null)

  useEffect(() => {
    if (!checkWebGLSupport()) setWebGLError("WebGL is not supported in your browser")
  }, [])

  const toggleFullscreen = () => {
    if (!containerRef.current) return
    if (!isFullscreen) containerRef.current.requestFullscreen?.()
    else document.exitFullscreen?.()
    setIsFullscreen(!isFullscreen)
  }

  useEffect(() => {
    const handler = () => setIsFullscreen(!!document.fullscreenElement)
    document.addEventListener("fullscreenchange", handler)
    return () => document.removeEventListener("fullscreenchange", handler)
  }, [])

  useEffect(() => {
    const fetchData = async () => {
      if (!Number.isFinite(id)) return
      try {
        const slotData = await parkingSlotsApi.get(id)
        setSlot(slotData)
        const floorData = await parkingFloorsApi.get(slotData.floor_id)
        setFloor(floorData)
        const lotData = await parkingLotsApi.get(floorData.parking_lot_id)
        setLot(lotData)
        const floorsData = await parkingFloorsApi.list({ parking_lot_id: lotData.id, limit: 100 })
        const safeFloors = Array.isArray(floorsData) ? floorsData : []
        setFloors(safeFloors)
        const slotsData: Record<number, ParkingSlotOut[]> = {}
        await Promise.all(safeFloors.map(async (f) => {
          const r = await parkingSlotsApi.list({ floor_id: f.id, limit: 100 })
          slotsData[f.id] = Array.isArray(r) ? r : []
        }))
        setSlotsByFloor(slotsData)
      } catch (e) { console.error(e) }
      finally { setIsLoading(false) }
    }
    fetchData()
  }, [id])

  if (isLoading) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="flex items-center justify-center h-64 text-muted-foreground">
        <p>Loading slot 3D view...</p>
      </div>
    </div>
  )
  if (!slot) return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="text-center py-20 text-muted-foreground">Slot not found.</div>
    </div>
  )

  const isAvailable = slot.status === "AVAILABLE"
  const isReserved = slot.status === "RESERVED"
  const floorName = floor?.floor_name || `Floor ${floor?.id}`

  const handleTrackSlot = () => {
    if (!lot || !slot) return
    trackParkingSlot(
      {
        slotNumber: slot.slot_number,
        floorName,
        latitude: slot.latitude,
        longitude: slot.longitude,
      },
      lot,
      setActiveNavigation
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 max-w-7xl mx-auto w-full p-4 sm:p-6 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Button variant="ghost" size="icon" className="size-8 -ml-2" onClick={() => navigate(-1)}>
                <ArrowLeft className="size-4" />
              </Button>
              <h1 className="text-lg font-semibold">Slot {slot.slot_number}</h1>
              <Badge variant={isAvailable ? "default" : isReserved ? "outline" : "secondary"} className={`text-xs ${isReserved ? "border-amber-500/50 text-amber-600" : ""}`}>
                {slot.status}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground pl-8">
              {lot?.name} · {floor?.floor_name || `Floor ${floor?.id}`}
              {slot.section ? ` · Section ${slot.section}` : ""}
            </p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" variant={isNightMode ? "default" : "outline"} onClick={() => setTheme(isNightMode ? "light" : "dark")} className="gap-2">
              {isNightMode ? <Sun className="size-3.5" /> : <Moon className="size-3.5" />}
              {isNightMode ? "Day Mode" : "Night Mode"}
            </Button>
            <Button size="sm" variant={isAutoRotate ? "default" : "outline"} onClick={() => setIsAutoRotate(!isAutoRotate)} className="gap-2">
              <RotateCw className={`size-3.5 ${isAutoRotate ? "animate-spin" : ""}`} />
              {isAutoRotate ? "Stop" : "Rotate"}
            </Button>
            <Button size="sm" variant="outline" onClick={toggleFullscreen} className="gap-2">
              {isFullscreen ? <Minimize2 className="size-3.5" /> : <Maximize2 className="size-3.5" />}
              {isFullscreen ? "Exit" : "Fullscreen"}
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
          <div className="lg:col-span-1 space-y-4">
            <div className={`rounded border p-4 space-y-3 ${isAvailable ? "border-emerald-500/30 bg-emerald-500/5" : isReserved ? "border-amber-500/30 bg-amber-500/5" : "border-red-500/30 bg-red-500/5"}`}>
              <div className="flex items-center gap-3">
                <div className={`size-12 rounded flex items-center justify-center ${isAvailable ? "bg-emerald-500/10 text-emerald-500" : isReserved ? "bg-amber-500/10 text-amber-500" : "bg-red-500/10 text-red-500"}`}>
                  {isAvailable ? <ParkingSquare className="size-6" /> : isReserved ? <Clock className="size-6" /> : <Car className="size-6" />}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground">Current Status</p>
                  <p className={`text-lg font-bold leading-tight ${isAvailable ? "text-emerald-500" : isReserved ? "text-amber-500" : "text-red-500"}`}>
                    {isAvailable ? "Available" : isReserved ? "Reserved" : "Occupied"}
                  </p>
                </div>
              </div>
              {lot && floor && (
                <Button
                  className="w-full gap-2 mt-2"
                  onClick={() => navigate(`/parking/${lot.id}?slotId=${slot.id}&floorId=${floor.id}`)}
                >
                  <ParkingSquare className="size-4" />
                  Book This Slot
                </Button>
              )}
              {!isAvailable && !isReserved && lot && floor && (
                <p className="text-[11px] text-amber-600 text-center leading-snug">
                  Currently occupied — pick a future start time when booking.
                </p>
              )}
              {isReserved && lot && floor && (
                <p className="text-[11px] text-amber-600 text-center leading-snug">
                  Reserved — you can still book a different time slot.
                </p>
              )}
              {lot && floor && (
                <Button
                  variant="outline"
                  className="w-full gap-2"
                  onClick={handleTrackSlot}
                >
                  <Navigation2 className="size-4" />
                  Track This Slot
                </Button>
              )}
            </div>

            {lot && floor && (
              <LocationTrackBar
                lotName={lot.name}
                floorName={floorName}
                slotNumber={slot.slot_number}
                onTrack={handleTrackSlot}
              />
            )}

            <Card>
              <CardContent className="pt-5 space-y-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Slot Info</p>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <div className="size-8 rounded bg-muted flex items-center justify-center shrink-0">
                      <Hash className="size-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Slot Number</p>
                      <p className="text-sm font-semibold">{slot.slot_number}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="size-8 rounded bg-muted flex items-center justify-center shrink-0">
                      <Layers className="size-4 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Floor</p>
                      <p className="text-sm font-semibold">{floor?.floor_name || `Floor ${floor?.id}`}</p>
                    </div>
                  </div>
                  {slot.section && (
                    <div className="flex items-center gap-3">
                      <div className="size-8 rounded bg-muted flex items-center justify-center shrink-0">
                        <MapPin className="size-4 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Section</p>
                        <p className="text-sm font-semibold">{slot.section}</p>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {lot?.owner && (
              <Card>
                <CardContent className="pt-5 space-y-3">
                  <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <Briefcase className="size-3.5 text-primary" /> Company Info
                  </p>
                  <div className="flex items-center gap-3">
                    {lot.owner.user?.profile_image_url || (lot.owner.user as any)?.profile_image ? (
                      <img
                        src={lot.owner.user?.profile_image_url || (lot.owner.user as any)?.profile_image}
                        alt={lot.owner.company_name || "Company"}
                        className="size-9 rounded-full object-cover border border-primary/30 shrink-0"
                      />
                    ) : (
                      <div className="size-9 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center text-primary font-bold text-xs shrink-0">
                        {(lot.owner.company_name || lot.owner.user?.full_name || lot.owner.user?.username || "C").charAt(0).toUpperCase()}
                      </div>
                    )}
                    <div className="min-w-0">
                      <p className="text-sm font-bold text-foreground truncate">
                        {lot.owner.company_name || "Independent Operator"}
                      </p>
                      <p className="text-xs text-muted-foreground truncate flex items-center gap-1">
                        <User className="size-3 shrink-0" />
                        <span>{lot.owner.user?.full_name || lot.owner.user?.username || "Owner"}</span>
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pt-1 border-t border-border/50">
                    {lot.owner.user?.email && (
                      <a
                        href={`mailto:${lot.owner.user.email}`}
                        title={`Email ${lot.owner.user.email}`}
                        className="p-1.5 rounded-md bg-muted border border-border text-primary hover:bg-primary/10 transition-colors inline-flex items-center justify-center"
                      >
                        <Mail className="size-3.5" />
                      </a>
                    )}
                    {lot.owner.user?.phone && (
                      <a
                        href={`tel:${lot.owner.user.phone}`}
                        title={`Call ${lot.owner.user.phone}`}
                        className="p-1.5 rounded-md bg-muted border border-border text-primary hover:bg-primary/10 transition-colors inline-flex items-center justify-center"
                      >
                        <Phone className="size-3.5" />
                      </a>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          <div className="lg:col-span-3">
            <div
              ref={containerRef}
              className={`relative w-full rounded overflow-hidden border shadow-xl transition-colors duration-300 ${isFullscreen ? "fixed inset-0 z-50 h-screen w-screen rounded-none border-none" : "h-[560px]"
                } ${isNightMode ? "bg-[#09090b] border-zinc-800" : "bg-card border-border"}`}
            >
              {webGLError ? (
                <WebGLFallback message={webGLError} />
              ) : (
                <Suspense fallback={<div className="flex items-center justify-center h-full text-muted-foreground">Loading 3D scene...</div>}>
                  <Canvas
                    camera={{ position: [0, 40, 18], fov: 42 }}
                    gl={{ antialias: true, alpha: false }}
                    dpr={[1, 1.5]}
                    frameloop="always"
                    onError={() => setWebGLError("Failed to initialize 3D rendering.")}
                  >
                    <Slot3DScene
                      floors={floors}
                      slotsByFloor={slotsByFloor}
                      isNightMode={isNightMode}
                      highlightedSlotId={id}
                      isAutoRotate={isAutoRotate}
                      reservedSlotIds={reservedSlotIds}
                    />
                  </Canvas>
                </Suspense>
              )}

              <div
                className={`absolute bottom-4 left-4 flex items-center gap-3 px-3.5 py-2 rounded text-xs font-medium backdrop-blur-md border transition-colors duration-300 ${isNightMode
                  ? "bg-slate-950/80 border-slate-800 text-slate-100 shadow-xl"
                  : "bg-white/80 border-slate-200 text-slate-800 shadow-md"
                  }`}
              >
                <span className="flex items-center gap-1.5">
                  <span className={`size-3 rounded ${isNightMode ? "bg-[#dc2626]" : "bg-[#ef4444]"}`} />
                  Occupied
                </span>
                <span className="flex items-center gap-1.5">
                  <span className={`size-3 rounded inline-block ${isNightMode ? "bg-[#d97706] shadow-[0_0_8px_rgba(245,158,11,0.6)]" : "bg-[#f59e0b]"}`} />
                  Reserved
                </span>
                <span className="flex items-center gap-1.5">
                  <span
                    className={`size-3 rounded border ${isNightMode ? "border-emerald-400 bg-emerald-500/40 shadow-[0_0_8px_rgba(16,185,129,0.5)]" : "border-emerald-600 bg-emerald-500/30"
                      }`}
                  />{" "}
                  Available
                </span>
                <span className="flex items-center gap-1.5"><span className="size-3 rounded bg-[#3b82f6] shadow-[0_0_8px_rgba(59,130,246,0.6)]" /> Selected</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {activeNavigation && (
        <ParkingTrackModal
          slotNumber={activeNavigation.slotNumber}
          floorName={activeNavigation.floorName}
          lotName={activeNavigation.lotName}
          destLatitude={activeNavigation.latitude}
          destLongitude={activeNavigation.longitude}
          onClose={() => setActiveNavigation(null)}
        />
      )}
      <Footer />
    </div>
  )
}
